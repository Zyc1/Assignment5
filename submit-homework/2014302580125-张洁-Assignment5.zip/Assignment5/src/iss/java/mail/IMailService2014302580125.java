package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class IMailService2014302580125 implements IMailService{
	String smtpHostName="smtp.163.com";
	String imapHostName="imap.163.com";
	String username="15527121553@163.com";
	String password="ibupsdbkseljmldw";
	
	/**
     * �����ʼ���props�ļ�
     */
    private final transient Properties props = System.getProperties();
    /**
     * �ʼ���������¼��֤
     */
    private transient MailAuthenticator2014302580125 authenticator;

    /**
     * ����session
     */
    private transient Session session;

	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", smtpHostName);
        props.put("mail.imap.host",imapHostName);
        props.put("mail.store.protocol", "imap");
        authenticator = new MailAuthenticator2014302580125(username, password);
        // ����session
        session = Session.getInstance(props, authenticator);
	}

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
		MimeMessage message = new MimeMessage(session);
		InternetAddress intaddsender=new InternetAddress(authenticator.getUsername());
		InternetAddress intaddreceiver=new InternetAddress(recipient);
        // ���÷�����
        message.setFrom(intaddsender);
        // �����ռ���
        message.setRecipient(RecipientType.TO, intaddreceiver);
        // ��������
        message.setSubject(subject);
        // �����ʼ�����
        message.setContent(content.toString(), "text/html;charset=utf-8");
        // ����
        Transport.send(message);
	}

	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		Store store = session.getStore();
        store.connect();
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);
       // folder.getMessages() != null;
        // folder.getUnreadMessageCount()!=0
        
        if(folder.hasNewMessages() )
        {
        	folder.close(false);
			store.close();	
			System.out.println("Receive an email.");
			return true;
        }
        else{
        	folder.close(false);
    		store.close();	
    		System.out.println("Not yet received an email.");
    		return false;
        }
      
	}

	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO Auto-generated method stub
		 Store store = session.getStore();
	        store.connect();
	        // ��������ڵ��ʼ���Folder������"ֻ��"��
	        Folder folder = store.getFolder("inbox");
	        folder.open(Folder.READ_WRITE);
	        int m=folder.getMessages().length;
	        Message  message=folder.getMessage(m);
	      
	        String emailTxt="";
	        //for(int i=0;i<m;i++)
	        //{
	        	emailTxt+=message.getContent().toString();
	       // emailTxt+=message.getContent();
	      // }
	        	 folder.close(true);
	             store.close();
		return emailTxt;
	}

}
